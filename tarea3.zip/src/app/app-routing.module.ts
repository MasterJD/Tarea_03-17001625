import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PrimoComponent } from './components/primo/primo.component';
import { CalculadoraComponent } from './components/calculadora/calculadora.component';
import { NotasComponent } from './components/notas/notas.component';


const routes: Routes = [

  { path: "Prime", component: PrimoComponent },
  { path: "Calculator", component: CalculadoraComponent },
  { path: "Grades", component: NotasComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
