import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-primo',
  templateUrl: './primo.component.html',
  styleUrls: ['./primo.component.css']
})
export class PrimoComponent implements OnInit {
  num1: number;

  constructor() { }

  ngOnInit(): void {


  }


  resultado() {

    if (this.num1 % 2 == 1) {
      document.getElementById("result").innerHTML = "Respuesta: Es primo";
    }
    else {
      document.getElementById("result").innerHTML = "Respuesta: No es primo";
    }
    this.num1 = null;
  }

}



