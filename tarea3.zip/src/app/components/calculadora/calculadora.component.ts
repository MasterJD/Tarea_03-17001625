import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calculadora',
  templateUrl: './calculadora.component.html',
  styleUrls: ['./calculadora.component.css']
})
export class CalculadoraComponent implements OnInit {

  in1: number;
  in2: number;
  result: number;

  constructor() { }

  ngOnInit(): void {
  }

  empty(num1, num2) {
    if (num1 == null || num2 == null) {
      return window.alert("ERROR, please insert values to operate.");
    }
    else {
      document.getElementById("result").innerHTML = "Respuesta: " + this.result.toString();
    }
  }
  suma() {
    this.result = this.in1 + this.in2;
    this.empty(this.in1, this.in2);

  }

  resta() {
    this.result = this.in1 - this.in2;
    this.empty(this.in1, this.in2);

  }
  multiplicacion() {
    this.result = this.in1 * this.in2;
    this.empty(this.in1, this.in2);

  }
  division() {
    this.result = this.in1 / this.in2;
    this.empty(this.in1, this.in2);

  }

  reset() {

    this.in1 = null;
    this.in2 = null;
  }


}
