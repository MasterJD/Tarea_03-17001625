import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notas',
  templateUrl: './notas.component.html',
  styleUrls: ['./notas.component.css']
})
export class NotasComponent implements OnInit {
  materia: string;
  nota: string;

  constructor() { }

  ngOnInit(): void {
  }

  agregar() {

    if (this.materia == null || this.nota == null) {
      window.alert("ERROR, please fill the input area");
    }
    else {
      var table: HTMLTableElement = <HTMLTableElement>document.getElementById("dy_table");
      var row = table.insertRow(0);
      var cell = row.insertCell(0);
      var cell2 = row.insertCell(1);
      table.style.border = "1px solid black";
      cell.style.borderTop = "1px solid black";
      cell.style.borderRight = "1px solid black";
      cell2.style.borderTop = "1px solid black";
      cell.innerHTML = this.materia;
      cell2.innerHTML = this.nota;
      this.materia = null;
      this.nota = null;
    }


  }

}
